Notes:  It is assumed that you have already installed anaconda from anaconda.com.  This installs python and Jupyter Notebook and Jupyter Lab programs among others.  

Install R (https://www.r-project.org/) and RStudio (https://posit.co/products/open-source/rstudio/)

By Default Jupyter Notebook and Jupyterlab are configured to only run Python.  You can however run R by installing the IRKernel. You can do this as follows:

Open R studio.  In the console of Rstudio type the following
install.packages('IRkernel')
Once the package is installed then type the following:
IRkernel::installspec(user=FALSE) if this does not work run without user=FALSE

Open a Jupyter Notebook (You can do so from anaconda)
Whe you click on new you will see R kernel.  Select R Kernel to start scriping in R.


The following Notebooks introduce you to R and comprise part 1 of the R Bootcamp.  They provide very basic information to get you started using R.  Remember you can only learn R via exploration.  



Bootcamp-Lesson1.ipynb 	Introduction to R
Bootcamp-Lesson2.ipynb	Set Working Directory & Read File
Bootcamp-Lesson3.ipynb	Basic Data Structures
Bootcamp-Lesson4.ipynb	One-Dimensional Data Structures (Vectors, Lists)
Bootcamp-Lesson5.ipynb	Multi-dimensional Numeric Data Structures - Matrix and Arrays
Bootcamp-Lesson6.ipynb	Multi-dimensional Data Structures - DataFrame and Read CSV Files
Bootcamp-Lesson7.ipynb	Basic Operations in R
Bootcamp-Lesson8.ipynb	R Programming Conditional Statements (IF, IF-ELSE, SWITCH)
Bootcamp-Lesson9.ipynb	R Programming Looping Statements (For and While Loops, Break, Next, Repeat)
Bootcamp-Lesson10.ipynb	R Programming User-Defined Functions
Bootcamp-Lesson11.ipynb	R Programming Vectorization (Apply family of functions)
Bootcamp-Lesson12.ipynb	R Programming Solving First-Order Ordinary Differential Equations
Climate-Beaumont.csv	Dataset or use in the R bootcamp	


